---
turi: bosh
---
# 🧠 Ikkinchi miya

> Hamma narsa shu yerdan boshlanadi. Yangi fikr → `00 Inbox`, kun → `01 Kunlik`, qaror → `04 Qarorlar`.

## Tezkor
- [[Qanday ishlatish]] — qoidalar va Claude bilan ishlash
- Bugungi kun: `Cmd+P` → "Daily notes: Open today's daily note"
- Yangi eslatma shablondan: `Cmd+P` → "Templates: Insert template"

## Loyihalar
- [[Growz]] — fermerlar uchun raqamli agronom
- [[Bizon]] — chorvadorlar ilovasi
- [[ERP]] — agro/vet dorixonalar ombor tizimi
- [[HRM]] — ichki HR va moliya tizimi
- [[USMLE]] — USMLE Step 1 test platformasi
- [[BetterFuture]] — jamoa va manbalar

## Faol loyihalar
```dataview
TABLE holat, muhimlik, yangilangan
FROM "02 Loyihalar"
WHERE turi = "loyiha"
SORT muhimlik ASC
```

## Ochiq qarorlar
```dataview
TABLE loyiha, sana
FROM "04 Qarorlar"
WHERE holat = "ochiq"
SORT sana DESC
```

## Inbox (tartiblash kerak)
```dataview
LIST
FROM "00 Inbox"
SORT file.ctime DESC
```

## Oxirgi uchrashuvlar
```dataview
TABLE loyiha, sana
FROM "05 Uchrashuvlar"
SORT sana DESC
LIMIT 10
```

## Ochiq vazifalar (hamma joydan)
```dataview
TASK
WHERE !completed AND !contains(file.folder, "99 Shablonlar")
GROUP BY file.link
LIMIT 30
```
