Uchrashuv qaydlari shu yerda: `YYYY-MM-DD Mavzu.md`. Shablon: `Cmd+P` → "Templates: Insert template" → Uchrashuv.
