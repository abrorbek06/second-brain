Bu yerga hamma narsani tez yozing — fikr, link, eslatma. Juma kuni tartiblanadi (yoki Claude'ga "Inbox'ni tartibla" deng).
