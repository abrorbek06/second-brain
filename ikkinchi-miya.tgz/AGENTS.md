# Ikkinchi miya — AI uchun qoidalar

Bu papka foydalanuvchining Obsidian vault'i (ikkinchi miyasi). Foydalanuvchi — product manager, BetterFuture jamoasida Growz, Bizon, ERP, HRM loyihalarini va alohida USMLE loyihasini olib boradi. Til: o'zbekcha (lotin).

## Tuzilma
- `00 Inbox/` — tartiblanmagan yozuvlar
- `01 Kunlik/` — `YYYY-MM-DD.md`
- `02 Loyihalar/` — har loyihaga bitta sahifa (frontmatter: turi: loyiha, holat, muhimlik, yangilangan)
- `03 Odamlar/` — `Ism Familiya.md`
- `04 Qarorlar/` — `YYYY-MM-DD Qisqa nom.md` (frontmatter: turi: qaror, loyiha, holat: ochiq|qabul qilingan|bekor, sana)
- `05 Uchrashuvlar/` — `YYYY-MM-DD Mavzu.md` (frontmatter: turi: uchrashuv, loyiha, sana, ishtirokchilar)
- `06 Bilim/` — o'rganilgan narsalar, qo'llanmalar
- `99 Shablonlar/` — yangi fayl yaratishda shu shablonlardan foydalan

## Qoidalar
1. Yangi fayl yaratishda `99 Shablonlar/`dagi mos shablonni ol va frontmatter maydonlarini to'ldir.
2. Loyiha, odam, qaror nomlarini doim `[[wikilink]]` bilan yoz. Mavjud fayl nomlaridan foydalan (`[[Growz]]`, `[[Bizon]]`, `[[ERP]]`, `[[HRM]]`, `[[USMLE]]`).
3. Faqat foydalanuvchi aytgan yoki manbada bor narsani yoz. O'z taxminingni fakt sifatida yozma; taxmin bo'lsa `> [!question]` callout ichida yoz.
4. Mavjud matnni o'chirma yoki qayta yozma — qo'sh. O'chirish kerak bo'lsa, foydalanuvchidan so'ra.
5. Uchrashuv yoki qaror yozganda tegishli loyiha sahifasining "Oxirgi yangiliklar" bo'limiga bir qatorli havola qo'sh.
6. Vazifalar `- [ ] matn 📅 YYYY-MM-DD` formatida.
7. Parol, API kalit, karta raqami kabi maxfiy ma'lumotlarni vault'ga yozma.
8. Loyiha tafsilotlari Notion/Figma/Jira'da turadi; vault'da qisqa xulosa va havola saqlanadi. Tafsilot eskirgan bo'lishi mumkin bo'lsa, manbani tekshirishni taklif qil.

## Qidiruv
Agar `graphify-out/graph.json` bo'lsa, keng savollarda avval `graphify query "<savol>"` ni ishlat, keyin fayllarni o'qi. Fayllar o'zgargach `graphify update .` (LLM'siz, bepul).
