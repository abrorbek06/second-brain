---
turi: qaror
loyiha: 
holat: ochiq
sana: {{date:YYYY-MM-DD}}
---
# {{title}}

**Loyiha:** [[ ]]
**Holat:** ochiq | qabul qilingan | bekor

## Muammo / savol
Nima hal qilinishi kerak?

## Variantlar
1. **A** — afzallik / kamchilik
2. **B** — afzallik / kamchilik

## Qaror
Nima tanlandi va **nega**.

## Oqibatlar
Nimalar o'zgaradi, kim nima qiladi.
