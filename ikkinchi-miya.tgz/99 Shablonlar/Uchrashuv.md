---
turi: uchrashuv
loyiha: 
sana: {{date:YYYY-MM-DD}}
ishtirokchilar: []
---
# {{title}}

**Loyiha:** [[ ]]
**Ishtirokchilar:** 

## Kun tartibi
- 

## Muhokama


## Kelishuvlar / qarorlar
- 

## Vazifalar
- [ ] kim — nima 📅 
