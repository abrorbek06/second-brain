---
turi: odam
rol: 
loyihalar: []
---
# {{title}}

**Rol:** 
**Loyihalar:** 

## Nima bilan shug'ullanadi
- 

## Eslatmalar
- 
