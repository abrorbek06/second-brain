---
turi: loyiha
holat: faol
muhimlik: 2
yangilangan: {{date:YYYY-MM-DD}}
---
# {{title}}

## Qisqacha
Nima, kim uchun, qanday muammoni hal qiladi.

## Holat
- 

## Jamoa
- 

## Ochiq savollar
- [ ] 

## Oxirgi yangiliklar
- 

## Manbalar
- Notion: 
- Figma: 
- Jira: 
