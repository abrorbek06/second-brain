---
turi: tashkilot
aliases: [loyihalar, jamoa]
---
# BetterFuture

Jamoa va loyihalar umumiy sahifasi.

## Loyihalar
- [[Growz]] — fermerlar uchun raqamli agronom (Jira SCRUM)
- Growz International — xalqaro varianti (qarang [[Growz]])
- [[Bizon]] — chorvadorlar ilovasi (Jira BIZ)
- [[ERP]] — dorixona/ombor ERP (Jira ERP)
- [[HRM]] — ichki HR va moliya (Jira HRM)
- Tadqiqot jamoasi — Jira TJ (bo'sh)

## Jamoa (2026)
| Kim | Rol |
|---|---|
| [[Farxod]] | CTO |
| [[G'olibjon]] | PM |
| [[Nodira]] | Dizayn |
| [[Fazliddin Nabijonov]] | Backend |
| [[Farrux]] | Backend |
| [[Abubakr]] | Backend |
| [[Abdug'aniy]] | Frontend |
| [[Azamat]] | Mobil |
| [[Yusufali]] | — |
| [[Jahongir Khan]] | — (Jira) |
| [[Jorayev Muhammadyor]] | — (Jira) |
| [[abdulvoxid.abdusaidov]] | — (Jira) |

## Manbalar
- Notion: workspace "Abrorbek06" — Growz, Bizon sahifalari, Product Tracker bazasi
- Figma: "Growz | Design", "Bizon | Design"
- Jira: betterfuture.atlassian.net — SCRUM, BIZ, ERP, HRM, TJ
