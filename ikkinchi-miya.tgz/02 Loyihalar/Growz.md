---
turi: loyiha
holat: faol
muhimlik: 1
yangilangan: 2026-11-23
aliases: [growz.uz, Growz Admin, Growz International]
---
# Growz

## Qisqacha
Fermerlar uchun **raqamli agronom**. Muammo: fermerlarda agronom yo'q → noto'g'ri sug'orish, kasallik kech aniqlanadi. Yechim: fermer maydonni chizadi, o'simlik ekadi → tizim ekishdan hosilgacha agrotadbirlar rejasini avtomatik tuzadi.

- **Stack:** mobil Flutter; admin React 19 + Vite + TS
- **Daromad:** Premium obuna (1/3/6/12 oy, ~7 kun sinov), AgroApteka hamkorligi, Growz bozor
- **Ko'lam (hujjatlarda):** ~39k fermer, ~2.6k agrodo'kon, 43 distribyutor
- **Growz International** — xalqaro varianti (Analytics + Development, OAuth)

## Asosiy modullar
- **rAIs** — AI maslahatchi: o'simlik → maydon → muammo → rasm → tashxis + preparatlar
- **Maydon va agro-reja** — xaritada maydon, avtomatik vazifalar timeline
- **AgroApteka** — preparat/o'g'it buyurtmasi (sotuvchi roli: Agroapteka)
- **Tuproq tahlili** — 8 ko'rsatkich, datchik yoki qo'lda (Oct 2026 da UI tayyor)
- **Agromoliya** — bank kreditlari (TBC, Hamkor, Octobank), faqat Premium
- **Growz bozor** — hosil sotish

## Holat (Nov 2026)
- Jira SCRUM: tuproq tahlili moduli tugagan; **savatcha (SCRUM-27)** jarayonda — [[Fazliddin Nabijonov]]
- To Do: SCRUM-25 barcha do'konlar bitta global ombor ([[ERP]] bilan bog'liq), SCRUM-30 "Product not found" bug, SCRUM-31 "rAIs bilan batafsil" kasallikni uzatmaydi

## Ochiq savollar
- [ ] rAIs tashxisini fermerga ko'rsatishdan oldin maslahatchi tasdiqlaydimi? (Notion: ha, Figma: yo'q)
- [ ] Ekish sanasisiz / bir nechta ekin bilan agro-reja qanday tuziladi?
- [ ] Growz bozor: bildirishnomadan keyingi savdo jarayoni
- [ ] AgroApteka: buyurtma statusini kim o'zgartiradi
- [ ] Narx valyutasi (UZS vs $) dizaynda aralash
- [ ] Bosh sahifadagi tugmalar pastki panelni takrorlaydi (dizayn taklifi #1 bajarilmagan)

## Oxirgi yangiliklar
- 2026-11-23 — sahifa yaratildi

## Manbalar
- Notion: [Growz](https://app.notion.com/p/Growz-39df7f6702ba801187dece87f6fd641e)
- Figma: [Growz | Design](https://www.figma.com/design/1qrPkBne0wauC0GJGPxs3z/Growz-%7C-Design) — eng to'liq manba: "PDF — Growz" sahifasi
- Jira: betterfuture.atlassian.net, loyiha **SCRUM**
- Admin: dev2-admin.growz.io · Yordam: t.me/GrowzYordamchi

Bog'liq: [[Bizon]] (o'xshash tuzilma, rAIsman maskoti), [[ERP]], [[BetterFuture]]
