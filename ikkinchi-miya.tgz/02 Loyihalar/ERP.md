---
turi: loyiha
holat: faol
muhimlik: 2
yangilangan: 2026-11-23
aliases: [Growz AgroVet ERP, Growz AgroVet]
---
# ERP

## Qisqacha
Agro va vet dorixonalar uchun **ombor/dorixona ERP**. [[Growz]] AgroApteka va "Growz AgroVet" admin dizayni (inventarizatsiya, filiallar o'rtasida ko'chirish, МОЛ) bilan bog'liq.

## Holat (Nov 2026, Jira ERP — 11 issue)
- **Tayyor (Oct 2026):** IKPU majburiy maydon, shtrix-kod bo'yicha qidiruv, kategoriya qo'lda yaratish, ko'chirish hujjati maydonlari, kirim hujjatida shtrix-kod, kirim narxini vet-apteka foydalanuvchilaridan yashirish, dorixona + davr bo'yicha kirim hisoboti, konsignatsiya testi — asosan [[Fazliddin Nabijonov]]
- **Jarayonda:** ERP-9 buyurtmalarni boshqarish UI — abdulvoxid.abdusaidov
- **To Do:** ERP-10 Списание (hisobdan chiqarish), ERP-11 Spisanie guruhi CRUD — egasi yo'q
- Bog'liq: Growz SCRUM-25 — barcha do'konlar bitta global ombor

## Ochiq savollar
- [ ] Spisanie kimga biriktiriladi?
- [ ] Jira'da "Done" vazifalar "In Progress" kategoriyasida ko'rinadi — workflow sozlamasini tuzatish

## Oxirgi yangiliklar
- 2026-11-23 — sahifa yaratildi

## Manbalar
- Jira: betterfuture.atlassian.net, loyiha **ERP**
- Figma: Growz | Design → "Admin page" (Growz AgroVet)

Bog'liq: [[Growz]], [[Bizon]], [[BetterFuture]]
