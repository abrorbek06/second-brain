---
turi: loyiha
holat: faol
muhimlik: 1
yangilangan: 2026-11-23
aliases: [Bizon Market]
---
# Bizon

## Qisqacha
**Chorvadorlar uchun ilova.** Asosiy qiymat — **kunlik ratsion**. Qo'shimcha: AI yordamchi, hayvon kartasi, veterinar chaqirish, Vet-apteka, Bizon Market.

- **Stack:** mobil Flutter, admin React; kontent 4 tilda
- **Rollar (mobil):** fermer, veterinar, vet-magazin
- **Admin:** 8 rol — Super admin, Admin, Distribyutor, Assistent, Zootexnik, Vet-menejer, Kontent menejer, Maslahatchi

## Asosiy modullar
- **Kunlik ratsion** — yosh guruhi → hayvon → an'anaviy/intensiv → ozuqalar → haftalik kun tartibi
- **AI yordamchi (rAIs)** — kasallik tavsifi → veterinar taklifi
- **Veterinar chaqirish** — PENDING → ACCEPTED → CAME → DONE
- **Vet-apteka** — savat, naqd yoki Payme
- **Market** — hayvon e'lonlari, narx taklifi, sevimlilar
- **Hayvon kartasi** — vazn/sut grafigi, tibbiy tarix

## Holat (Nov 2026)
- Product Tracker: Development → Testing; ratsion kategoriyalari, Bizon bozor
- Jamoa: [[Abubakr]] (backend), [[Abdug'aniy]] (frontend), [[Azamat]] (mobil)
- Jira BIZ — bo'sh (0 issue)

## Ochiq savollar
- [ ] Ratsionni kim tuzadi: AI ("Haftalik tavsiya") yoki zootexnik qo'lda? (Notion va Figma farq qiladi)
- [ ] Zot ratio koeffitsienti ratsionda qanday ishlatiladi
- [ ] Veterinar band qilishda vaqt oralig'i yo'q
- [ ] Ikki xil ariza enum; TREATMENT statusi ishlatilmaydi
- [ ] Dashboard mock ma'lumotda
- [ ] "Moliya" bo'limi dizaynda bor, Notion'da yo'q
- [ ] Ekranlarda til aralash (UZ + RU + EN), placeholder matnlar

## Oxirgi yangiliklar
- 2026-11-23 — sahifa yaratildi

## Manbalar
- Notion: [Bizon](https://app.notion.com/p/39ff7f6702ba807999ebe8442a7d8cb5)
- Figma: [Bizon | Design](https://www.figma.com/design/pFWvfE2x5s4xA2GqueHzsD/Bizon-%7C-Design)
- Jira: loyiha **BIZ**

Bog'liq: [[Growz]], [[ERP]] (vet dorilar), [[BetterFuture]]
