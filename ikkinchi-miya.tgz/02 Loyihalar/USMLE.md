---
turi: loyiha
holat: faol
muhimlik: 2
yangilangan: 2026-11-23
aliases: [USMLE Step 1]
---
# USMLE

## Qisqacha
**USMLE Step 1** uchun mock-test va savollar banki platformasi.

- **Kod:** `~/Projects/usmle` — `usmle-backend` (NestJS + Prisma) va `usmle-frontend` (React + Vite + Tailwind, pnpm)
- **Deploy:** server (hujjat: "USMLE — serverga deploy")
- **Asosiy hujjatlar (repo ildizida):** `PROJECT_MASTER_CONTEXT.md` (to'liq kontekst, "Project Memory for Future AI Sessions" bo'limi bor), `PROJECT_STABILIZATION_AUDIT.md`, har repo'da `STATUS.md`

## Modullar (graphify grafidan)
- **Identity / Auth** — JWT, email/telefon tasdiqlash, Telegram, OAuth
- **Question Bank** — savollar, import (question-intake format v1), bookmark, eslatmalar
- **Test Engine** — test yaratish, yechish, natija tahlili, tarix
- **Mock Exams** — imtihon simulyatsiyasi
- **Study Planner** — o'quv reja generatori
- **Flashcards** — kartochkalar va takrorlash jadvali
- **Study Library / Reference Library** — maqolalar, laboratoriya qiymatlari
- **Performance analytics**, landing (StageShow demo)

## Xotira (graphify)
- Graf: `~/Projects/usmle/graphify-out/` — 6013 node, 263 bo'lim
- Wiki: `graphify-out/wiki/index.md` (273 maqola)
- So'rov: `cd ~/Projects/usmle && graphify query "savol"`

## Holat
- 

## Ochiq savollar
- [ ] 

## Oxirgi yangiliklar
- 2026-11-22 — graphify grafi va wiki quruldi
- 2026-11-23 — sahifa yaratildi
