---
turi: loyiha
holat: faol
muhimlik: 2
yangilangan: 2026-11-23
---
# HRM

## Qisqacha
Ichki **HR + moliya tizimi**: xodimlar, shartnomalar (loyihalarga bog'langan, jumladan [[Growz]]/[[Bizon]]), "Стартапы" sahifasi, ish haqi (Excel), P&L (Excel/PDF), cash-flow prognozi, ko'p valyuta (UZS/USD), xizmat so'rovlari va tasdiqlash, vazifalar, audit log, AI yordamchi.

## Holat (Nov 2026, Jira HRM)
- **32 ta bug** (HRM-12…43), QA 11–16 Nov 2026; hammasi To Do, hammasi [[Fazliddin Nabijonov]]da
- Hech narsa jarayonda emas

## Eng muhim buglar
- [ ] HRM-12 Bosh sahifa jami valyutani hisobga olmaydi
- [ ] HRM-13 P&L valyutani hisobga olmaydi
- [ ] HRM-14 Loyihani o'chirib bo'lmaydi
- [ ] HRM-15 Tasdiqlangan so'rov summasini o'zgartirsa bo'ladi
- [ ] HRM-16 O'chirilgan so'rov tasdiqlangan to'lovni qoldiradi
- [ ] HRM-17 Takroriy so'rov raqamlari
- [ ] HRM-18 Audit log harakatlarni yozmaydi
- [ ] HRM-19 "123" parolli foydalanuvchi yaratsa bo'ladi

Xavfsizlik: HRM-35 (chiqishdan keyin eski token ishlaydi), HRM-36, HRM-39, HRM-32. Moliya: HRM-22, 23, 24, 25, 33, 43.

## Ochiq savollar
- [ ] 32 bugning hammasi bitta odamda — taqsimlash kerakmi?

## Oxirgi yangiliklar
- 2026-11-23 — sahifa yaratildi

## Manbalar
- Jira: betterfuture.atlassian.net, loyiha **HRM**

Bog'liq: [[BetterFuture]]
