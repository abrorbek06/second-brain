---
turi: odam
rol: CTO
loyihalar: []
---
# Farxod

**Rol:** CTO
**Loyihalar:** —
**Jamoa:** [[BetterFuture]]

## Nima bilan shug'ullanadi
- 

## Eslatmalar
- 
