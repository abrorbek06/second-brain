---
turi: odam
rol: Dizayner
loyihalar: [Growz, Bizon]
---
# Nodira

**Rol:** Dizayner
**Loyihalar:** [[Growz]], [[Bizon]]
**Jamoa:** [[BetterFuture]]

## Nima bilan shug'ullanadi
- 

## Eslatmalar
- 
