---
turi: odam
rol: PM
loyihalar: []
---
# G'olibjon

**Rol:** PM
**Loyihalar:** —
**Jamoa:** [[BetterFuture]]

## Nima bilan shug'ullanadi
- 

## Eslatmalar
- 
