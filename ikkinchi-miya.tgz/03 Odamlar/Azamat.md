---
turi: odam
rol: Mobil
loyihalar: [Bizon]
---
# Azamat

**Rol:** Mobil
**Loyihalar:** [[Bizon]]
**Jamoa:** [[BetterFuture]]

## Nima bilan shug'ullanadi
- 

## Eslatmalar
- 
