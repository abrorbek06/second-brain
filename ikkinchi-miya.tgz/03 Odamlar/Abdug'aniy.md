---
turi: odam
rol: Frontend
loyihalar: [Bizon]
---
# Abdug'aniy

**Rol:** Frontend
**Loyihalar:** [[Bizon]]
**Jamoa:** [[BetterFuture]]

## Nima bilan shug'ullanadi
- 

## Eslatmalar
- 
