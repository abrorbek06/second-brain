---
turi: odam
rol: Backend
loyihalar: [Growz, ERP, HRM]
---
# Fazliddin Nabijonov

**Rol:** Backend
**Loyihalar:** [[Growz]], [[ERP]], [[HRM]]
**Jamoa:** [[BetterFuture]]

## Nima bilan shug'ullanadi
- Jira'dagi ochiq ishlarning ko'pi unda: barcha [[HRM]] buglari, [[Growz]] savatcha (SCRUM-27), [[ERP]] global ombor (SCRUM-25)

## Eslatmalar
- 
