---
turi: odam
rol: 
loyihalar: [Growz, ERP]
---
# Jorayev Muhammadyor

**Rol:** —
**Loyihalar:** [[Growz]], [[ERP]]
**Jamoa:** [[BetterFuture]]

## Nima bilan shug'ullanadi
- [[Growz]]: SCRUM-5 AI agent (o'g'it/dori ma'lumoti); [[ERP]]: ERP-8 konsignatsiya testi

## Eslatmalar
- 
