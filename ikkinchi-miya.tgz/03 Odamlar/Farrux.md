---
turi: odam
rol: Backend
loyihalar: []
---
# Farrux

**Rol:** Backend
**Loyihalar:** —
**Jamoa:** [[BetterFuture]]

## Nima bilan shug'ullanadi
- 

## Eslatmalar
- 
