---
turi: odam
rol: 
loyihalar: [Growz]
---
# Jahongir Khan

**Rol:** —
**Loyihalar:** [[Growz]]
**Jamoa:** [[BetterFuture]]

## Nima bilan shug'ullanadi
- [[Growz]]: SCRUM-26 bepul foydalanuvchilar uchun prognozni xiralashtirish

## Eslatmalar
- 
