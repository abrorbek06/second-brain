---
turi: odam
rol: Backend
loyihalar: [Bizon]
---
# Abubakr

**Rol:** Backend
**Loyihalar:** [[Bizon]]
**Jamoa:** [[BetterFuture]]

## Nima bilan shug'ullanadi
- 

## Eslatmalar
- 
