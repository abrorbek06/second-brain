---
turi: odam
rol: 
loyihalar: [ERP]
---
# abdulvoxid.abdusaidov

**Rol:** —
**Loyihalar:** [[ERP]]
**Jamoa:** [[BetterFuture]]

## Nima bilan shug'ullanadi
- [[ERP]]: ERP-9 buyurtmalarni boshqarish UI (jarayonda)

## Eslatmalar
- 
