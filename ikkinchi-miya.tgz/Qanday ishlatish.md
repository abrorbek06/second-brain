# Qanday ishlatish

## Papkalar
| Papka | Nima uchun |
|---|---|
| `00 Inbox` | Tez yozilgan, hali tartiblanmagan hamma narsa. Haftada bir tozalanadi |
| `01 Kunlik` | Kunlik qaydlar: nima qildim, nima o'ylayapman |
| `02 Loyihalar` | Har loyihaga bitta asosiy sahifa (holat, qarorlar, ochiq savollar) |
| `03 Odamlar` | Jamoa va hamkorlar: kim nima bilan shug'ullanadi |
| `04 Qarorlar` | Har bir muhim qaror alohida: nima, nega, qanday muqobillar bor edi |
| `05 Uchrashuvlar` | Uchrashuv qaydlari va kelishuvlar |
| `06 Bilim` | O'qigan, o'rgangan narsalar, vositalar bo'yicha qo'llanmalar |
| `99 Shablonlar` | Shablonlar (tegmang) |

## Oddiy qoidalar
1. **Avval Inbox'ga.** Qayerga qo'yishni o'ylab o'tirmang — Inbox'ga yozing, keyin tartiblaysiz.
2. **Bog'lang.** Loyiha, odam yoki qaror nomini `[[ ]]` ichida yozing: `[[Growz]]`, `[[Fazliddin Nabijonov]]`. Shu bilan grafda bog'lanish paydo bo'ladi.
3. **Qaror = alohida fayl.** "Nega shunday qilgan edik?" degan savolga keyin javob topish uchun.
4. **Vazifa = `- [ ]`.** Har qanday sahifada yozilgan vazifa [[Bosh sahifa]]da yig'iladi.

## Haftalik tartib (juma, 15 daqiqa)
- [ ] Inbox'ni bo'shatish: har bir eslatmani loyiha / qaror / bilim papkasiga ko'chirish yoki o'chirish
- [ ] Loyiha sahifalarida "Holat" bo'limini yangilash
- [ ] Ochiq qarorlarni ko'rib chiqish

## Claude bilan ishlash
Vault papkasida Claude Code yoki Codex'ni oching (yoki Claude desktop'da shu papkani ulang) va oddiy tilda so'rang:
- "Bugungi uchrashuvni yozib qo'y: Growz, Fazliddin bilan, savatcha 1-dekabrgacha tayyor bo'ladi" → `05 Uchrashuvlar`ga yozadi, [[Growz]]ga havola qo'shadi
- "Inbox'ni tartibla" → har bir eslatmani to'g'ri papkaga ko'chiradi
- "Bizon'da veterinar chaqirish bo'yicha nima qaror qilgan edik?" → vault va grafdan javob beradi
- "Bu haftaning xulosasini yoz" → kunlik qaydlar va uchrashuvlardan haftalik xulosa

AI uchun qoidalar [[CLAUDE]] faylida.

## Graf
- Obsidian'ning o'z grafi: chap paneldagi "Graph view" (yoki `Cmd+G`)
- Chuqur graf (graphify): vault papkasida `graphify update .` → `graphify-out/graph.html`
