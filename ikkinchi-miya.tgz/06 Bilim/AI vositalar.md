---
turi: bilim
sana: 2026-11-23
---
# AI vositalar (Mac'dagi sozlama)

## Graphify — kod va hujjatlar grafi
- O'rnatilgan: `uv tool` (Python 3.12), `graphify 0.9.x`, SQL qo'llab-quvvatlash bilan
- Ulangan: Claude Code, Codex, VS Code Copilot Chat; Graphify Cloud (MCP) — Codex'da kirilgan, Claude Code'da `/mcp` → Authenticate
- Buyruqlar: `graphify update .` (LLM'siz yangilash), `graphify query "savol"`, `graphify explain "X"`, `graphify path A B --undirected`, `graphify export wiki`
- [[USMLE]] uchun graf tayyor

## OmniRoute — AI router (localhost:20128)
- Yoqish: `omniroute serve` · to'xtatish: `omniroute stop` · dashboard: `omniroute dashboard`
- Provayderlar: Groq ✅, Ollama (qwen3:4b) ✅, OpenAI (balans kerak), Gemini (kalit qayta kerak)
- Fallback: `combo/asosiy` = Groq GPT-OSS 120B → Qwen3.8 27B → GPT-OSS 20B → Ollama
- Mijoz kaliti: `~/.omniroute/client-key.env`; VS Code: OmniCopilot kengaytmasi
- Kalit qo'shish: `~/OmniRoute-kalitlar.command`
- Obunalar (ChatGPT/Claude) ulanmagan — akkaunt bloklanish xavfi tufayli

## Ollama — lokal model
- Yoqish: `brew services start ollama` · to'xtatish: `brew services stop ollama`
- Model: `qwen3:4b` (~2.5 GB). Mac 8 GB RAM — og'ir

## Ponytail — "dangasa senior dev" rejimi
- Claude Code'da ✅ (claude.ai'dan sinxron, v5.3.3); Codex'da hali yo'q
- `/ponytail lite|full|ultra|off`, `/ponytail-review`, `/ponytail-audit`, `/ponytail-debt`

## Obsidian — shu ikkinchi miya
- Qoidalar: [[Qanday ishlatish]], AI uchun: [[CLAUDE]]
